Getting Started
---------------

Start the sip servlets container from bin directory with ./catalina.bat run or ./catalina.sh run command. 
You should see a bunch of stuff on the console saying that some sip servlet applications have been added.	
Now that you can start it, you can play with the examples bundled with the release. For more information, check this link out http://www.mobicents.org/examples.html

There is an Application Router Management Console at this location http://localhost:8080/sip-servlets-management.
This application will help you to more easily configure the default application router.

The default port for SIP is 5080. There is one predeployed sample application - click2call. You can navigate to http://localhost:8080/click2call in order to see it in action.
